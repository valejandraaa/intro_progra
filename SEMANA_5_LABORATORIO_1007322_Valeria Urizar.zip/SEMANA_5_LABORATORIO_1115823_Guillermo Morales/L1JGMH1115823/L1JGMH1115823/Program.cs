﻿using System;

class Program
{
    static void Main(string[] args)
    {
        /*Console.WriteLine("Hola mundo");*/
         /* Console.WriteLine("soy NOMBRE");*/

         /* Console.Write("Hola Mundo");
          Console.Write("soy Guillermo");*/

         /* Console.ReadKey();
          Console.ReadLine();*/

        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy " + Nombre);

        Console.Write("Hola Mundo");
        Console.Write(" soy " + Nombre);
        Console.ReadLine();

    }

}